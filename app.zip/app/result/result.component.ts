import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/http';
import { OnlineTestService } from '../services/online-test.service';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  constructor(private httpClient:HttpClient,private onlineTestService:OnlineTestService) { }
  private answersList;
  private answerGiven;
  private result=[];
  ngOnInit() {
    this.httpClient.get('assets/answers.json').subscribe((res)=>{
      this.answersList = res["answers"]
      this.answerGiven = this.onlineTestService.$answers;
      for(let i=0;i<this.answerGiven.length;i++){
        if(this.answerGiven[i].selectedOption != undefined){
          for(let j=0;j<this.answersList.length;j++){
            if(this.answerGiven[i].quetionKey == this.answersList[j].quetionKey){
              if(this.answerGiven[i].selectedOption.value == this.answersList[j].answer.answerKey){
                let obj={
                  "question":this.answerGiven[i].question,
                  "status":"Correct answer",
                  "selectedAnswer": "("+this.answerGiven[i].selectedOption.value+")"+this.answerGiven[i].selectedOption.key
                }
                this.result.push(obj);
              }else{
                let obj={
                  "question":this.answerGiven[i].question,
                  "status":"Wrong answer",
                  "selectedAnswer": "("+this.answerGiven[i].selectedOption.value+")"+this.answerGiven[i].selectedOption.key,
                  "correctAnswer": "("+this.answersList[j].answer.answerKey+")"+this.answersList[j].answer.answer
                }
                this.result.push(obj);
              }
            }
          }
        }else{
          for(let j=0;j<this.answersList.length;j++){
            if(this.answerGiven[i].quetionKey == this.answersList[j].quetionKey){
              let obj={
                "question":this.answerGiven[i].question,
                "status":"Wrong answer",
                "selectedAnswer": "No answer selected",
                "correctAnswer": "("+this.answersList[j].answer.answerKey+")"+this.answersList[j].answer.answer
              }
              this.result.push(obj);
            }
          }

        }
      }
      console.log(this.result)

    });

  }

}
