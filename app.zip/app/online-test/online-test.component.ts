import { Component, OnInit } from '@angular/core';
import {RegistrationService} from '../services/registration.service';
import { HttpClient } from '@angular/http';
import { OnlineTestService } from '../services/online-test.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-online-test',
  templateUrl: './online-test.component.html',
  styleUrls: ['./online-test.component.css']
})
export class OnlineTestComponent implements OnInit {

  constructor(private registrationService:RegistrationService,private httpClient:HttpClient,private onlineTestService:OnlineTestService,private router:Router) { }
  private name;
  private questionList;
  ngOnInit() {
    this.name = this.registrationService.$name
    this.httpClient.get('assets/questions.json').subscribe((res)=>{
      this.questionList = res["questions"]
        console.log(res);
    });
  }

  onSelectionChange(entry,index){
    this.questionList[index]["selectedOption"]=entry;
  }

  onSubmitClick(){
    this.onlineTestService.$answers = this.questionList;
    this.router.navigate(['/result'])
  }

}
