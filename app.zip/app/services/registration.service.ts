import { Injectable } from '@angular/core';

@Injectable()
export class RegistrationService {

  constructor() { }

    /**
     * Getter $name
     * @return {string}
     */
	public get $name(): string {
		return this.name;
	}

    /**
     * Setter $name
     * @param {string} value
     */
	public set $name(value: string) {
		this.name = value;
	}
  private name:string;

}
