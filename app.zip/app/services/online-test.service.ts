import { Injectable } from '@angular/core';

@Injectable()
export class OnlineTestService {

  constructor() { }

    /**
     * Getter $answers
     * @return {any}
     */
	public get $answers(): any {
		return this.answers;
	}

    /**
     * Setter $answers
     * @param {any} value
     */
	public set $answers(value: any) {
		this.answers = value;
	}
  private answers:any;

}
